/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tenacle.sgr.components;

import com.tenacle.sgr.entities.PaymentMode;
import com.tenacle.sgr.entities.Ticket;
import com.tenacle.sgr.persistence.tools.DB;
import com.vaadin.shared.ui.ContentMode;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Label;
import com.vaadin.ui.themes.ValoTheme;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import org.vaadin.viritin.layouts.MGridLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

/**
 *
 * @author samuel
 */
public class PaymentComponent extends MVerticalLayout {

    //holds the list of tickets
    List<Ticket> tickets = new ArrayList<Ticket>();

    //get All payment modes
    List<PaymentMode> paymentModes = DB.getInstance().get(PaymentMode.class).findAll();

    //one payment method
    ComboBox<PaymentMode> paymentMethod = new ComboBox<>("Select Payment Method", paymentModes);

    PaymentMode paymentMode = null;
    Label amountToPay = new Label("", ContentMode.HTML);

    NumberFormat format = NumberFormat.getCurrencyInstance();

    double amount = 0.0;

    public PaymentComponent() {
        paymentMethod.addStyleName(ValoTheme.COMBOBOX_LARGE);

        paymentMethod.addValueChangeListener(p -> {
            this.paymentMode = paymentMethod.getValue();
        });

        add(amountToPay, paymentMethod);
    }

    public void addTicket(Ticket ticket) {
        amount += ticket.getFromAmount() + ticket.getToAmount();
        tickets.add(ticket);
        changeAmountLabel(amount);
    }

    public void removeTicket(Ticket ticket) {
        amount -= ticket.getFromAmount() + ticket.getToAmount();
        tickets.remove(ticket);
        changeAmountLabel(amount);
    }

    private void changeAmountLabel(double amount) {
        amountToPay.setCaption("Pay Kes. <b>" + format.format(amount) + "</b> with");
        amountToPay.setContentMode(ContentMode.HTML);
    }

}
